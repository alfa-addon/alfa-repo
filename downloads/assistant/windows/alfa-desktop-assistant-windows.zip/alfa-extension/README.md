# Web Sniffer
Extension for Chromium

[Versión]
Atención: Desde el 17/01/22 el Chrome Web Store ya no acepta el Manifest V2. Se recomienda V3: https://developer.chrome.com/docs/extensions/mv2/declare_permissions/
Manifest v2: https://developer.chrome.com/docs/extensions/mv2/declare_permissions/
Manifest v3: https://developer.chrome.com/docs/extensions/mv3/declare_permissions/

[Refactor]
Permissions innecesarios hasta la fecha que se podría eliminar: "*://*", "chrome-extension://*", "bookmarks", "unlimitedStorage"

[Pdte]
//TODO Corrige en contentScript.js que método "sendInfoToAssDesktopByMessage" no está enviando el body de los iframes (¿tal vez haya que enumerar los iframes y enviar contenido?)
         Éste parece NO ir (añadido en sendMessage: 	data.url = "!!" + data.url): 
            ("https://www.google.com/recaptcha/api2/anchor?ar=1&k=6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0DJwx_mJ-&co=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbTo0NDM.&hl=en&v=M-QqaF9xk6BpjLH22uHZRhXt&size=normal&sa=action&cb=a4ok7wilp3p9")
//TODO añade "malwareBlockRule" a addHtmlSourcesVisited
//TODO Control el onload de la Web principal
//TODO Consigue requestHeaders: 
        https://stackoverflow.com/questions/23434674/how-to-access-request-headers-in-onheadersreceived-event-in-chrome-extension
        (using blob) https://stackoverflow.com/questions/4325968/window-open-with-headers
//TODO Create tab es mejor:
        https://stackoverflow.com/questions/2149917/chrome-extensions-how-to-know-when-a-tab-has-finished-loading-from-the-backgr
        Inyectar headers o user agent: https://stackoverflow.com/questions/7978232/chrome-extension-modify-user-agent-string
        El del 23:  https://stackoverflow.com/questions/2149917/chrome-extensions-how-to-know-when-a-tab-has-finished-loading-from-the-backgr
        https://bocoup.com/blog/spoofing-user-agent-with-chromes-webrequest-api
//TODO No se está cargando ningún fichero filtro malware
//TODO- Cambia el install.sh e install.cmd para eliminar el Chrome y el Java descargado de Alfa si ya existe uno en sistema
//TODO- Cambia el install.sh e install.cmd para aceptar el parámetro opcional KEEP_JAVA o KEEP_CHROME
//TODO: Si cancel Postman!!!
//TODO Get full code ALWAYS (using your own devTool): https://betterprogramming.pub/chrome-extension-intercepting-and-reading-the-body-of-http-requests-dd9ebdf2348b
//TODO Instead sharing using cookies is better using Chrome storage (so you will use common.js ya que contentScript no tiene acceso a document.cookies): https://itsallbinary.com/custom-chrome-extension-code-add-modify-request-headers-good-example-for-beginners/
//TODO Error in background.js (Extension manifest must request permission to access this host) por ejemplo con:
            http://127.0.0.1:48884/getSourceByPageFinished?url=aHR0cHM6Ly93YWF3LnRvL3dhdGNoX3ZpZGVvLnBocD92PUwwczFNa0U0U1RGWmJrdEtURkJqT1hBeU1pdHhhMUJPVWpaME5XNTZkMDlwTkZkaU16VTBZa3czUjNCSlVVSXZUR05NT1Vwa1VqZHhTVkZ4UzNaS1NnJTNEJTNEJmh0dHBfcmVmZXJlcj1odHRwcyUzQSUyRiUyRmhkZnVsbC5saW5rJTJGI2lzcz1PVFF1TWpVeUxqRXlNUzR4TVRZPQ==&time=6000&cache=false&debug=true
//TODO Comprueba que aún funciona recaptcha V2:
            http://127.0.0.1:48884/getSourceByPageFinished?getCookies=true&debug=true&removeAllCookies=false&clearWebCache=false&url=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9yZWNhcHRjaGEvYXBpMi9kZW1v&time=3500&cache=false

//TODO? Crea tu propio DevTools: https://developer.chrome.com/docs/extensions/mv3/devtools/

//TODO? onResponseBodyReceived => no existe!!?
//OK- Usa función "toggleMuteState" para mutear cada TAB abierto. NOTA: No se puede usar el parémtro "--mute-audio" de chrome ya que mutearía otras instancias si es el Chrome del usuario
//NO- Activar VPN en OPERA ¿pero cómo elegir país?
   chrome.settingsPrivate.setPref("freedom.proxy_switcher.enabled", true) && chrome.settingsPrivate.setPref("freedom.proxy_switcher.ui_visible", true)
//OK- Considera usar chrome.tabs.onUpdated.addListener() que parece que te permite recoger los cambios habidos en la web
//OK- Muta todo tab (busca y usa la función ya hecha aquí "toggleMuteState")
-Run JS
             chrome.tabs.executeScript({
                 code: 'document.body.style.backgroundColor="orange"'
             });

             or

             chrome.tabs.executeScript(tabId, {file: 'login.js'}, callback);
- Get body communication:
  - Valor de la cookie a usar en Java: En JS enviamos todo pero en Java se enviará a Alfa:
       "cookies": [
          {
           "cookiesList": "GUCS=AU5IzJ-l",    # "key1=value1;key2=value2"
            "urls": [
              "https://www.yahoo.com",               # La URL es la que ofrece onVisited (siempre finalizada en /), pero si proviene de getAllCookies debería de ser cookie.URL (aunque hasta Chrome 88 está vacía) o cookie.host (también puede estar vacío pero es debido a que significa que es host-only (??) -pondré un "*"-). Ver referencia en (*) 
              "https://edge-mcdn.secure.yahoo.com",
              "https://consent.yahoo.com",
              "https://csp.yahoo.com"
            ]
          },
        {
          "cookiesList": "null",
          "urls": [
            "https://s.yimg.com"
          ]
        }

        (*): Referencia: Reference: https://developer.chrome.com/docs/extensions/reference/cookies/#type-Cookie


[Issues]
Full finished load
No me esperaba ésto, estoy dándole muchas vueltas a la detección del fin-del-load de una Web (lo que incluye que JS haya incluso terminado) y no encuentro una solución correcta y nativa (en mi extensión Chrome) ya que recibo múltiples onLoad (uno por cada recurso abierto/descargado) y el principal aleatoriamente es el primero o no... Complicado, en fin...
Esta detección se necesita porque hay métodos en Assistant que llamé "getXXXByPageFinished" que esperan a que la página termine. Por eso actualmente tú tienes que esperar 15 segundos de más (el máximo a aplicar), porque aún no sé cómo detectar fin de load completo... En fin, a seguir, son batallas que voy ganando poco a poco, no queda tanto para una versión operativa...

************************** pdte ************
[App parámetros]
Se soporta:
- open
- openAndQuit (1 shot open and close chrome -but app keeps working-)
- openAndTerminate (1 shot open and close chrome + app)

No se soporta:
- update
- updateMalwareList
- checkPermissions
- terminate
- updateAndTerminate


[Query parámetros]
Aparte de muchas features se soportan parámetros:
- debug
- removeallCookies
- clearWebCache
- removeAllCookies
- cache
- time
- extraPostDelay
- terminate/quit
- ping
- mute (en realidad se ignora ya que se mutea por defecto)
- debug

Aún no lo tengo e iré haciendo por el siguiente orden:
- getCookies
- returnWhenCookieNameFound
- headers
- userAgent
- version
- jsCode
- jsDirectCodeNoReturn
- jsDirectCode2NoReturn
- password (network password)
- getData
- postData
- malwareWhiteList (aunque sí que se ha implementado el filtro antimalware y funciona bien)
- awakingInterval



[Retornos]
Se devuelve:
- URLs
- Sources (incluso de iframes ^_^)
- "malwareBlockRule" (regla que filtró una URL que se detectó malware)
- Errores

Pendiente devolver:
- Request headers (en ello aún)
- Cookies (en ello aún)
- Method (en ello aún



[Métodos]
Listo:
- terminate      <= Terminate app
- quit           <= Cierra Chrome


Pendiente:
- getSourceByTimeOut
- getSourceByPageFinished
- getJSResult
- getUrlsByPageFinished
- ping
- update


