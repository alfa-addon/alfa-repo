# -*- coding: utf-8 -*-
#------------------------------------------------------------
from core import urlparse as alfa_urlparse
import re

from platformcode import config, logger
from core import scrapertools
from core.item import Item
from core import servertools
from core import httptools
from core import urlparse
from bs4 import BeautifulSoup
from modules import autoplay

list_quality = []
list_servers = []


    # const SERVER1_URL = "https://iceyfile.com/video/embed/48f40715f3cc4359/640x320/bigtitcreampie.26.02.21.octokuro.480p.mp4";
    # const SERVER2_URL = "https://turbovidhls.com/t/6999c3e74a0b9";
    # const SERVER3_URL = "https://hgcloud.to/e/aryz40rcfhcs";


canonical = {
             'channel': 'porn4days', 
             'host': config.get_setting("current_host", 'porn4days', default=''), 
             'host_alt': ["https://porn4days.pw/"], 
             'host_black_list': ["https://porn4days.blue/", "https://porn4days.red/", "https://porn4days.biz/"], 
             'set_tls': True, 'set_tls_min': True, 'retries_cloudflare': 1, 'cf_assistant': False, 
             'CF': False, 'CF_test': False, 'alfa_s': True
            }
host = canonical['host'] or canonical['host_alt'][0]


def mainlist(item):
    logger.info()
    itemlist = []
    
    autoplay.init(item.channel, list_servers, list_quality)
    
    itemlist.append(Item(channel=item.channel, title="Nuevos" , action="lista", url=alfa_urlparse.build_url(host, 'newest/page1')))
    itemlist.append(Item(channel=item.channel, title="Mas vistos" , action="lista", url=alfa_urlparse.build_url(host, 'popullar/page1')))
    itemlist.append(Item(channel=item.channel, title="Canal" , action="canal", url=alfa_urlparse.build_url(host, 'paysitelist')))
    itemlist.append(Item(channel=item.channel, title="Categorias" , action="categorias", url=alfa_urlparse.build_url(host, 'tags')))
    itemlist.append(Item(channel=item.channel, title="Buscar", action="search"))
    
    autoplay.show_option(item.channel, itemlist)
    
    return itemlist


def search(item, texto):
    logger.info()
    _url_query_texto = texto
    texto = texto.replace(" ", "+")
    item.url = alfa_urlparse.build_url(host, 'search/page1/', query=[('s', u'{}'.format(_url_query_texto))])
    try:
        return lista(item)
    except Exception:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def canal(item):
    logger.info()
    itemlist = []
    soup = create_soup(item.url)
    matches = soup.find_all('div', class_='col-lg-3')
    for elem in matches:
        url = elem.a['href']
        title = elem.a.text
        url = urlparse.urljoin(host,url)
        thumbnail = ""
        plot = ""
        itemlist.append(Item(channel=item.channel, action="lista", title=title, url=url,
                              thumbnail=thumbnail , plot=plot) )
    return itemlist


def categorias(item):
    logger.info()
    itemlist = []
    soup = create_soup(item.url)
    matches = soup.find_all('div', class_='col-lg-3')
    for elem in matches:
        url = elem.a['href']
        thumbnail = elem.img['src']
        title = elem.img['alt']
        url = urlparse.urljoin(host,url)
        thumbnail = urlparse.urljoin(host,thumbnail)
        plot = ""
        itemlist.append(Item(channel=item.channel, action="lista", title=title, url=url,
                              thumbnail=thumbnail , plot=plot) )
    itemlist.sort(key=lambda x: x.title)
    return itemlist


def create_soup(url, referer=None, unescape=False):
    logger.info()
    if referer:
        data = httptools.downloadpage(url, headers={'Referer': referer}, canonical=canonical).data
    else:
        data = httptools.downloadpage(url, canonical=canonical).data
    if unescape:
        data = scrapertools.unescape(data)
    soup = BeautifulSoup(data, "html5lib", from_encoding="utf-8")
    return soup


def lista(item):
    logger.info()
    itemlist = []
    soup = create_soup(item.url)
    matches = soup.find_all('div', class_='video-card')
    for elem in matches:
        # logger.debug(elem)
        url = elem.a['href']
        title = elem.img['alt']
        thumbnail = elem.img['src']
        time = elem.find('span', class_='right')
        canal = elem.find('a', href=re.compile('search/\?s='))
        if canal:
            time = time.text.strip()
            canal = canal.text.strip()
            title = "[COLOR yellow]%s[/COLOR] [COLOR cyan]%s[/COLOR] %s" % (time,canal,title)
        else:
            time = time.text.strip()
            title = "[COLOR yellow]%s[/COLOR] %s" % (time,title)
        url = urlparse.urljoin(host,url)
        thumbnail = urlparse.urljoin(host,thumbnail)
        plot = ""
        # action = "play"
        # if logger.info() is False:
            # action = "findvideos"
        itemlist.append(Item(channel=item.channel, action="findvideos", title=title, url=url, thumbnail=thumbnail,
                               plot=plot, fanart=thumbnail, contentTitle=title ))
    next_page = soup.find(class_='pagination').find_all('a')[-1]
    if next_page:
        next_page = next_page['href']
        # if "/?s=" in item.url and not"/search/" in next_page:
            # next_page = "/search%s" %next_page
        next_page = urlparse.urljoin(host,next_page)
        if len(itemlist) == 24:
            itemlist.append(Item(channel=item.channel, action="lista", title="[COLOR blue]Página Siguiente >>[/COLOR]", url=next_page) )
    return itemlist
    
    
def findvideos(item):
    logger.info(item)
    itemlist = []
    data = httptools.downloadpage(item.url).data
    videos = scrapertools.find_multiple_matches(data, r'SERVER\d+_URL = "([^"]+)"')
    logger.debug(videos)
    for elem in videos:
        url = elem
        if url:
            itemlist.append(Item(channel=item.channel, action="play", title= "%s", contentTitle = item.title, url=url))
    itemlist = servertools.get_servers_itemlist(itemlist, lambda i: i.title % i.server.capitalize())
    
    # Requerido para AutoPlay
    autoplay.start(itemlist, item)
    return itemlist

