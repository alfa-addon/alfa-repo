# -*- coding: utf-8 -*-
#------------------------------------------------------------
from core import urlparse as alfa_urlparse
import re

from platformcode import config, logger
from core import scrapertools
from core.item import Item
from core import servertools
from core import httptools
from core import urlparse
from bs4 import BeautifulSoup


canonical = {
             'channel': 'porndoe', 
             'host': config.get_setting("current_host", 'porndoe', default=''), 
             'host_alt': ["https://porndoe.com/"], 
             'host_black_list': [], 
             'set_tls': True, 'set_tls_min': True, 'retries_cloudflare': 1, 'cf_assistant': False, 
             'CF': False, 'CF_test': False, 'alfa_s': True
            }
host = canonical['host'] or canonical['host_alt'][0]


def mainlist(item):
    logger.info()
    itemlist = []
    itemlist.append(Item(channel=item.channel, title="Nuevos" , action="lista", url=alfa_urlparse.build_url(host, 'videos')))
    itemlist.append(Item(channel=item.channel, title="Exclusivos" , action="lista", url=alfa_urlparse.build_url(host, 'category/74/premium-hd')))
    itemlist.append(Item(channel=item.channel, title="Mas vistos" , action="lista", url=alfa_urlparse.build_url(host, 'videos', query='sort=views-down')))
    itemlist.append(Item(channel=item.channel, title="Mejor valorado" , action="lista", url=alfa_urlparse.build_url(host, 'videos', query='sort=likes-down')))
    itemlist.append(Item(channel=item.channel, title="Mas largo" , action="lista", url=alfa_urlparse.build_url(host, 'videos', query='sort=duration-down')))
    itemlist.append(Item(channel=item.channel, title="PornStar" , action="categorias", url=alfa_urlparse.build_url(host, 'pornstars')))
    itemlist.append(Item(channel=item.channel, title="Canal" , action="categorias", url=alfa_urlparse.build_url(host, 'channels', query='sort=ranking')))
    itemlist.append(Item(channel=item.channel, title="Categorias" , action="categorias", url=alfa_urlparse.build_url(host, 'categories', query='sort=name')))
    itemlist.append(Item(channel=item.channel, title="Buscar", action="search"))
    return itemlist


def search(item, texto):
    logger.info()
    _url_query_texto = texto
    texto = texto.replace(" ", "+")
    item.url = alfa_urlparse.build_url(host, 'search', query=[('keywords', u'{}'.format(_url_query_texto))])
    try:
        return lista(item)
    except Exception:
        import sys
        for line in sys.exc_info():
            logger.error("%s" % line)
        return []


def has_class_but_no_id(tag):
    return not tag.has_attr('class_')
    
def categorias(item):
    logger.info()
    itemlist = []
    soup = create_soup(item.url)
    if "channels" in item.url:
        match1 = soup.find('div', class_='channels-list').find_all('div', class_='channels-item-thumb')
        matches =[]
        for elem in match1:
            matches.append(elem.parent)
    if "categories" in item.url:
        matches = soup.find_all(href=re.compile(r"/category/"))
    if "pornstars" in item.url:
        matches = soup.find_all('div', class_='actors-list-item')

    for elem in matches:
        cantidad = ""
        title = ""
        if "categories" in item.url:
            url = elem['href']
            title = elem['title']
            cantidad = elem.find('span')
        else:
            if elem.find(href=re.compile(r"/channel-profile/")):
                url = elem.find(href=re.compile(r"/channel-profile/"))['href']
            else:
                url = elem.a['href']
            cantidad = elem.find('span', class_='-grow')
            title = elem.a['title']
        thumbnail  = elem.svg['data-src']
        if cantidad:
            cantidad = cantidad.text.strip().replace(" Videos", "").replace(" videos", "")
            title = "%s (%s)" % (title, cantidad)
        url = url.replace("channel-profile", "channel-profile-videos")
        url = url.replace("https://letsdoeit.com", "")
        url = urlparse.urljoin(item.url, url)
        if "categories" in item.url:
            url = alfa_urlparse.update_query(url, sort='release')
        else:
            url = alfa_urlparse.update_query(url, sort='date-down')
        itemlist.append(Item(channel=item.channel, action="lista", title=title, url=url,
                              fanart=thumbnail, thumbnail=thumbnail, plot="") )
    next_page = soup.find('a', class_='pager-next')
    if next_page:
        next_page = next_page['href']
        next_page = urlparse.urljoin(host,next_page)

        itemlist.append(Item(channel=item.channel, action="categorias", title="[COLOR blue]Página Siguiente >>[/COLOR]", url=next_page) )
    return itemlist


def create_soup(url, referer=None, unescape=False):
    logger.info()
    if referer:
        data = httptools.downloadpage(url, headers={'Referer': referer}, canonical=canonical).data
    else:
        data = httptools.downloadpage(url, canonical=canonical).data
    if unescape:
        data = scrapertools.unescape(data)
    soup = BeautifulSoup(data, "html5lib", from_encoding="utf-8")
    return soup


def lista(item):
    logger.info()
    itemlist = []
    soup = create_soup(item.url)
    matches = soup.find_all('div', class_='video-item')
    for elem in matches:
        if "redirect" in elem.a['href']:
            continue
        url = elem.a['href']
        # id = elem.a['ng-pop-under']
        # url = "%svideo/%s" %(host,id)
        title = elem.find('a', class_='video-item-link')['aria-label']
        thumbnail = elem.svg['data-src']
        time = elem['data-duration']
        hd = elem['data-hd']
        vr = elem['data-vr']
        quality = ""
        if "true" in vr:
            quality = "VR"
        if "true" in hd:
            quality = "HD"
        url = urlparse.urljoin(host,url)
        thumbnail = urlparse.urljoin(host,thumbnail)
        title = "[COLOR yellow]%s[/COLOR] [COLOR red]%s[/COLOR] %s" % (time,quality,title)
        action = "play"
        if logger.info() is False:
            action = "findvideos"
        itemlist.append(Item(channel=item.channel, action=action, title=title, url=url, thumbnail=thumbnail,
                                fanart=thumbnail, contentTitle=title ))
    next_page = soup.find('a', class_='pager-next')
    if next_page:
        next_page = next_page['href']
        next_page = urlparse.urljoin(host,next_page)
        itemlist.append(Item(channel=item.channel, action="lista", title="[COLOR blue]Página Siguiente >>[/COLOR]", url=next_page) )
    return itemlist


def findvideos(item):
    logger.info()
    itemlist = []
    itemlist.append(Item(channel=item.channel, action="play", title= "%s", contentTitle = item.contentTitle, url=item.url))
    itemlist = servertools.get_servers_itemlist(itemlist, lambda i: i.title % i.server.capitalize())
    return itemlist


def play(item):
    logger.info()
    itemlist = []
    
    soup = create_soup(item.url).find('div', class_='player-left')
    pornstars = soup.find_all('a', href=re.compile("/pornstars-profile/[A-z0-9-]+"))
    for x , value in enumerate(pornstars):
        pornstars[x] = value.text.strip()
    pornstar = ' & '.join(pornstars)
    pornstar = "[COLOR cyan]%s[/COLOR]" % pornstar
    plot = ""
    if len(pornstars) <= 3:
        lista = item.contentTitle.split()
        if "HD" in item.title:
            lista.insert (4, pornstar)
        else:
            lista.insert (2, pornstar)
        item.contentTitle = ' '.join(lista)
    else:
        plot = pornstar
    
    itemlist.append(Item(channel=item.channel, action="play", title= "%s", contentTitle = item.contentTitle, url=item.url))
    itemlist = servertools.get_servers_itemlist(itemlist, lambda i: i.title % i.server.capitalize())
    return itemlist
